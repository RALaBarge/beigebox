"""BeigeBox TUI — a hacker-themed terminal interface."""
