"""Allow running BeigeBox via: python -m beigebox <command>"""
from beigebox.cli import main
main()
